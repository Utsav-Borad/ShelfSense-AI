from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework import status
from rest_framework.test import APIClient

from business.models import Business
from categories.models import Category
from products.models import Product
from suppliers.models import Supplier

from .models import Inventory


class InventoryAPITestCase(TestCase):
    def setUp(self):
        self.client = APIClient()

        self.user = get_user_model().objects.create_user(
            full_name="Test Owner",
            email="owner@example.com",
            password="strong-password-123",
        )
        self.client.force_authenticate(user=self.user)

        self.business = Business.objects.create(
            owner=self.user,
            shop_name="ShelfSense Mart",
            shop_type="Grocery",
            address="12 Market Street",
            phone="9876543210",
            gst_number="GST1234567",
        )

        self.category = Category.objects.create(
            business=self.business,
            category_name="Groceries",
            description="Daily grocery items",
        )

        self.supplier = Supplier.objects.create(
            business=self.business,
            supplier_name="ABC Traders",
            phone="9000000000",
            email="abc@example.com",
            address="45 Supply Road",
            status=Supplier.Status.ACTIVE,
        )

        self.product = Product.objects.create(
            business=self.business,
            category=self.category,
            supplier=self.supplier,
            barcode="1234567890",
            product_name="Milk",
            brand="Fresh Dairy",
            unit="Litre",
            mrp="50.00",
            selling_price="45.00",
            manufacturing_date="2026-01-01",
            expiry_date="2026-12-31",
            minimum_stock=10,
            status=Product.Status.ACTIVE,
        )

        self.inventory_payload = {
            "product": self.product.id,
            "available_quantity": 25,
            "reserved_quantity": 5,
            "damaged_quantity": 1,
        }

    def test_create_inventory_returns_standard_response(self):
        response = self.client.post(
            "/api/v1/inventory/",
            self.inventory_payload,
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(response.data["status"])
        self.assertEqual(response.data["message"], "Inventory created successfully.")
        self.assertEqual(response.data["data"]["available_quantity"], self.inventory_payload["available_quantity"])
        self.assertEqual(Inventory.objects.count(), 1)

    def test_list_inventory_returns_only_current_business_inventory(self):
        Inventory.objects.create(
            product=self.product,
            available_quantity=25,
            reserved_quantity=5,
            damaged_quantity=1,
        )

        response = self.client.get("/api/v1/inventory/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["status"])
        self.assertEqual(len(response.data["data"]), 1)
        self.assertEqual(response.data["data"][0]["available_quantity"], 25)

    def test_get_inventory_returns_inventory_details(self):
        inventory = Inventory.objects.create(
            product=self.product,
            available_quantity=25,
            reserved_quantity=5,
            damaged_quantity=1,
        )

        response = self.client.get(f"/api/v1/inventory/{inventory.id}/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["status"])
        self.assertEqual(response.data["data"]["id"], inventory.id)
        self.assertEqual(response.data["data"]["available_quantity"], inventory.available_quantity)

    def test_update_inventory_changes_inventory_details(self):
        inventory = Inventory.objects.create(
            product=self.product,
            available_quantity=25,
            reserved_quantity=5,
            damaged_quantity=1,
        )

        updated_payload = {
            "product": self.product.id,
            "available_quantity": 30,
            "reserved_quantity": 6,
            "damaged_quantity": 2,
        }

        response = self.client.put(
            f"/api/v1/inventory/{inventory.id}/",
            updated_payload,
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["status"])
        self.assertEqual(response.data["message"], "Inventory updated successfully.")
        self.assertEqual(response.data["data"]["available_quantity"], updated_payload["available_quantity"])

        inventory.refresh_from_db()
        self.assertEqual(inventory.available_quantity, updated_payload["available_quantity"])
        self.assertEqual(inventory.reserved_quantity, updated_payload["reserved_quantity"])

    def test_create_inventory_with_negative_quantity_returns_validation_error(self):
        invalid_payload = dict(self.inventory_payload)
        invalid_payload["available_quantity"] = -1

        response = self.client.post(
            "/api/v1/inventory/",
            invalid_payload,
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertFalse(response.data["status"])
        self.assertIn("available_quantity", response.data["errors"])

    def test_get_inventory_for_missing_id_returns_not_found(self):
        response = self.client.get("/api/v1/inventory/999999/")

        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_delete_inventory_removes_inventory(self):
        inventory = Inventory.objects.create(
            product=self.product,
            available_quantity=25,
            reserved_quantity=5,
            damaged_quantity=1,
        )

        response = self.client.delete(f"/api/v1/inventory/{inventory.id}/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(response.data["status"])
        self.assertEqual(response.data["message"], "Inventory deleted successfully.")
        self.assertEqual(Inventory.objects.count(), 0)

    def test_unauthenticated_user_cannot_access_inventory(self):
        self.client.force_authenticate(user=None)

        response = self.client.get("/api/v1/inventory/")

        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
