from rest_framework import status
from rest_framework.exceptions import NotFound
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from business.models import Business

from .models import Inventory
from .serializers import InventorySerializer
from .services import InventoryService


def _get_owner_business_or_404(owner: object) -> Business:
    """Return the authenticated user's business or raise a 404-style API error."""
    try:
        return Business.objects.get(owner=owner)
    except Business.DoesNotExist as error:
        raise NotFound("Business not found.") from error


class InventoryListView(APIView):
    """Create inventory and list inventory records for the authenticated user's business."""

    permission_classes = (IsAuthenticated,)

    def get(self, request):
        business = _get_owner_business_or_404(request.user)
        inventory_items = InventoryService.get_inventory_for_business(business)
        payload = {
            "status": True,
            "message": "Success",
            "data": InventorySerializer(inventory_items, many=True).data,
        }
        return Response(payload)

    def post(self, request):
        business = _get_owner_business_or_404(request.user)
        serializer = InventorySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        try:
            inventory = InventoryService.create_inventory(business, serializer.validated_data)
        except ValueError as error:
            payload = {
                "status": False,
                "message": str(error),
                "data": {},
                "errors": {"product": [str(error)]},
            }
            return Response(payload, status=status.HTTP_400_BAD_REQUEST)

        payload = {
            "status": True,
            "message": "Inventory created successfully.",
            "data": InventorySerializer(inventory).data,
        }
        return Response(payload, status=status.HTTP_201_CREATED)


class InventoryDetailView(APIView):
    """Retrieve, update, or delete inventory for the authenticated user's business."""

    permission_classes = (IsAuthenticated,)

    def get(self, request, inventory_id):
        business = _get_owner_business_or_404(request.user)
        try:
            inventory = InventoryService.get_inventory_for_business_by_id(business, inventory_id)
        except Inventory.DoesNotExist as error:
            raise NotFound("Inventory not found.") from error

        payload = {
            "status": True,
            "message": "Success",
            "data": InventorySerializer(inventory).data,
        }
        return Response(payload)

    def put(self, request, inventory_id):
        business = _get_owner_business_or_404(request.user)
        try:
            inventory = InventoryService.get_inventory_for_business_by_id(business, inventory_id)
        except Inventory.DoesNotExist as error:
            raise NotFound("Inventory not found.") from error

        serializer = InventorySerializer(inventory, data=request.data)
        serializer.is_valid(raise_exception=True)
        updated_inventory = InventoryService.update_inventory(inventory, serializer.validated_data)
        payload = {
            "status": True,
            "message": "Inventory updated successfully.",
            "data": InventorySerializer(updated_inventory).data,
        }
        return Response(payload)

    def delete(self, request, inventory_id):
        business = _get_owner_business_or_404(request.user)
        try:
            inventory = InventoryService.get_inventory_for_business_by_id(business, inventory_id)
        except Inventory.DoesNotExist as error:
            raise NotFound("Inventory not found.") from error

        InventoryService.delete_inventory(inventory)
        payload = {
            "status": True,
            "message": "Inventory deleted successfully.",
            "data": {},
        }
        return Response(payload)
