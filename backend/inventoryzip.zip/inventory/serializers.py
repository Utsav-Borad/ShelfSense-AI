from rest_framework import serializers

from .models import Inventory


class InventorySerializer(serializers.ModelSerializer):
    """Serialize inventory records and validate editable inventory information."""

    class Meta:
        model = Inventory
        fields = (
            "id",
            "product",
            "available_quantity",
            "reserved_quantity",
            "damaged_quantity",
            "last_updated",
        )
        read_only_fields = ("id", "last_updated")

    def validate_available_quantity(self, value):
        if value < 0:
            raise serializers.ValidationError("Available quantity cannot be negative.")
        return value

    def validate_reserved_quantity(self, value):
        if value < 0:
            raise serializers.ValidationError("Reserved quantity cannot be negative.")
        return value

    def validate_damaged_quantity(self, value):
        if value < 0:
            raise serializers.ValidationError("Damaged quantity cannot be negative.")
        return value
