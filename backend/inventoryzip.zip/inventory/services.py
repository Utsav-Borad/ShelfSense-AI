from typing import Any

from business.models import Business

from .models import Inventory


class InventoryService:
    """Business-layer operations for inventory."""

    @staticmethod
    def get_inventory_for_business(business: Business) -> list[Inventory]:
        """Return all inventory records belonging to the supplied business."""
        return list(
            Inventory.objects.filter(product__business=business).order_by("id")
        )

    @staticmethod
    def get_inventory_for_business_by_id(business: Business, inventory_id: int) -> Inventory:
        """Return a single inventory record for the supplied business."""
        return Inventory.objects.get(product__business=business, id=inventory_id)

    @staticmethod
    def create_inventory(business: Business, validated_data: dict[str, Any]) -> Inventory:
        """Create inventory and attach it to the supplied business."""
        product = validated_data.pop("product")
        if product.business != business:
            raise ValueError("Product does not belong to the supplied business.")
        return Inventory.objects.create(product=product, **validated_data)

    @staticmethod
    def update_inventory(inventory: Inventory, validated_data: dict[str, Any]) -> Inventory:
        """Persist validated editable fields for an existing inventory record."""
        for field_name, value in validated_data.items():
            setattr(inventory, field_name, value)

        inventory.save()
        return inventory

    @staticmethod
    def delete_inventory(inventory: Inventory) -> None:
        """Delete the supplied inventory record."""
        inventory.delete()
